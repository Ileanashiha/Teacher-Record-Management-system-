<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
<
            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button> 
                <a class="navbar-brand" href="dashboard.php">TRMS ADMIN | </a>
                
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
  <li class="active">
                        <a href="queries.php"> <i class="menu-icon fa fa-files-o"></i>Queries </a>
                    </li>
  <li class="active">
                        <a href="profile.php"> <i class="menu-icon fa fa-user"></i>Profile </a>
                    </li>
                      <li class="active">
                        <a href="change-password.php"> <i class="menu-icon fa fa-cog"></i>Change Password </a>
                    </li>
                      <li class="active">
                        <a href="logout.php"> <i class="menu-icon fa fa-power-off"></i>Logout </a>
                    </li>




                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>